// Optional presentation layer. Failures here must never stop the launcher from booting.
import { html, useEffect, useState } from '../vendor/preact-htm.js';
import { call, inTauri } from './api.js';
import { toast } from './store.js';

export const BRAND = 're-openOMSI';
export const DISPLAY_VERSION = '0.3.41.1';
const DEFAULTS = { accent: '#a78bfa', amoled: false, sidebar_dim: 78, sidebar_x: 50, loading_dim: 65, sidebar: false, loading: false };
const KEY = 're-openomsi-appearance-v1';
const IMAGE_LIMIT = 20 * 1024 * 1024;
let current = { ...DEFAULTS };
let pictures = {};
let revision = 0;
const listeners = new Set();

export function checked(value = {}) {
  const clamp = (x, lo, hi, fallback) => Number.isFinite(Number(x)) ? Math.min(hi, Math.max(lo, Math.round(Number(x)))) : fallback;
  return {
    accent: /^#[0-9a-f]{6}$/i.test(value.accent || '') ? value.accent : DEFAULTS.accent,
    amoled: value.amoled === true,
    sidebar_dim: clamp(value.sidebar_dim, 55, 95, 78),
    sidebar_x: clamp(value.sidebar_x, 0, 100, 50),
    loading_dim: clamp(value.loading_dim, 40, 90, 65),
    sidebar: value.sidebar === true,
    loading: value.loading === true,
  };
}
function cached() {
  try { return checked(JSON.parse(localStorage.getItem(KEY) || '{}')); } catch { return { ...DEFAULTS }; }
}
export function imageURL(slot) {
  if (!inTauri) return pictures[slot] || '';
  const root = /Windows/i.test(navigator.userAgent) ? 'http://omsi.localhost/' : 'omsi://localhost/';
  return `${root}reopen/${slot}.png?v=${revision}`;
}
export function applyAppearance(value) {
  current = checked(value);
  const style = document.documentElement.style;
  const hex = current.accent.slice(1);
  const rgb = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const luminance = rgb.map((v) => { const c = v / 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; });
  const lum = luminance[0] * .2126 + luminance[1] * .7152 + luminance[2] * .0722;
  document.documentElement.classList.toggle('reopen-amoled', current.amoled);
  style.setProperty('--accent', current.accent);
  style.setProperty('--accent-hover', current.accent);
  style.setProperty('--accent-text', lum > .179 ? '#111111' : '#ffffff');
  style.setProperty('--accent-soft', `rgba(${rgb.join(',')},0.16)`);
  style.setProperty('--focus', `rgba(${rgb.join(',')},0.6)`);
  for (const slot of ['sidebar', 'loading']) {
    style.setProperty(`--reopen-${slot}-image`, current[slot] && imageURL(slot) ? `url("${imageURL(slot)}")` : 'none');
    style.setProperty(`--reopen-${slot}-dim`, String(current[`${slot}_dim`] / 100));
    document.documentElement.classList.toggle(`reopen-${slot}-custom`, current[slot]);
  }
  style.setProperty('--reopen-sidebar-x', `${current.sidebar_x}%`);
  listeners.forEach((fn) => fn({ ...current }));
}
export async function initAppearance() {
  applyAppearance(cached());
  if (!inTauri) return;
  try {
    const value = await call('reopen_appearance_get');
    applyAppearance(value);
    try { localStorage.setItem(KEY, JSON.stringify(current)); } catch { /* native file remains authoritative */ }
  } catch (e) { console.warn('Optional appearance settings unavailable:', e.message); }
}
async function save(value) {
  const next = checked(value);
  if (inTauri) await call('reopen_appearance_save', { value: next });
  else {
    // Browser preview uses local storage; the installed launcher uses a separate JSON file.
    localStorage.setItem(KEY, JSON.stringify(next));
  }
  if (inTauri) { try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* not needed */ } }
  applyAppearance(next);
}
export async function rasterise(file) {
  if (!file || !['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) throw new Error('Wybierz obraz PNG, JPG lub WebP.');
  if (file.size > IMAGE_LIMIT) throw new Error('Obraz może mieć maksymalnie 20 MB.');
  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = url;
    await image.decode();
    if (!image.naturalWidth || !image.naturalHeight || image.naturalWidth * image.naturalHeight > 50_000_000) throw new Error('Obraz jest za duży (maks. 50 megapikseli).');
    const ratio = Math.min(1, 1600 / image.naturalWidth, 1600 / image.naturalHeight, Math.sqrt(1_440_000 / (image.naturalWidth * image.naturalHeight)));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.floor(image.naturalWidth * ratio));
    canvas.height = Math.max(1, Math.floor(image.naturalHeight * ratio));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Nie udało się przygotować obrazu.');
    ctx.fillStyle = '#121212'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!blob || blob.size > 6 * 1024 * 1024) throw new Error('Nie udało się zmieścić obrazu w limicie 6 MB.');
    return blob;
  } finally { URL.revokeObjectURL(url); }
}
export function AppearancePage() {
  const [value, setValue] = useState(() => ({ ...current }));
  const [busy, setBusy] = useState(false);
  const [sidebarAspect, setSidebarAspect] = useState(232 / 800);
  useEffect(() => {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;
    const update = () => {
      const rect = sidebar.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) setSidebarAspect(rect.width / rect.height);
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(sidebar);
    return () => observer.disconnect();
  }, []);
  useEffect(() => { listeners.add(setValue); return () => listeners.delete(setValue); }, []);
  const commit = async (patch) => {
    setBusy(true);
    try { await save({ ...current, ...patch }); } catch (e) { toast(e.message, 'error'); }
    finally { setBusy(false); }
  };
  const upload = async (slot, event) => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = '';
    if (!file) return;
    setBusy(true);
    let temporary;
    try {
      const blob = await rasterise(file);
      if (inTauri) await call('reopen_image_save', { slot, bytes: Array.from(new Uint8Array(await blob.arrayBuffer())) });
      else { temporary = URL.createObjectURL(blob); }
      if (temporary) { if (pictures[slot]) URL.revokeObjectURL(pictures[slot]); pictures[slot] = temporary; }
      revision++;
      await save({ ...current, [slot]: true });
      toast(slot === 'loading' ? 'Tło zapisane. W grze pojawi się przy następnym uruchomieniu sesji.' : 'Tło menu zapisane.', 'ok');
    } catch (e) { toast(e.message, 'error'); }
    finally { setBusy(false); }
  };
  return html`<section class="reopen-personalisation" aria-busy=${busy}>
    <header class="page-head"><div><h1>Wygląd</h1><p>${BRAND} ${DISPLAY_VERSION} · baza openOMSI 0.3.41</p></div></header>
    <p class="muted">Własne tła i kolor akcentu. Zmiany są zapisywane osobno od ustawień gry.</p>
    <fieldset disabled=${busy} class="reopen-options">
      <section class="card card-body"><h2>Kolorystyka</h2>
        <label class="reopen-control">Tryb AMOLED (prawdziwa czerń) <input type="checkbox" checked=${value.amoled} onChange=${(e) => commit({ amoled: e.currentTarget.checked })} /></label>
        <label class="reopen-control">Kolor akcentu <input aria-label="Kolor akcentu" type="color" value=${value.accent} onChange=${(e) => commit({ accent: e.currentTarget.value })} /></label>
        <div class="reopen-swatches">${['#a78bfa', '#e8a030', '#60a5fa', '#34d399', '#fb7185'].map((color) => html`<button type="button" aria-label=${`Akcent ${color}`} aria-pressed=${value.accent.toLowerCase() === color} style=${{ background: color }} onClick=${() => commit({ accent: color })}></button>`)}</div>
      </section>
      ${[['sidebar', 'Tło menu bocznego'], ['loading', 'Tło ekranu ładowania']].map(([slot, label]) => html`<section class="card card-body">
        <h2>${label}</h2>
        <label class="reopen-control">Wybierz obraz <input type="file" accept="image/png,image/jpeg,image/webp" aria-label=${label} onChange=${(e) => upload(slot, e)} /></label>
        <p class="small muted">PNG, JPG lub WebP, do 20 MB. Obraz zostanie zmniejszony do maks. 1,44 MP.</p>
        <label class="reopen-control">Przyciemnienie: ${value[`${slot}_dim`]}%
          <input type="range" min=${slot === 'sidebar' ? 55 : 40} max=${slot === 'sidebar' ? 95 : 90} value=${value[`${slot}_dim`]} aria-label=${`Przyciemnienie ${slot}`} onChange=${(e) => commit({ [`${slot}_dim`]: Number(e.currentTarget.value) })} />
        </label>
        ${slot === 'sidebar' ? html`
          <label class="reopen-control">Kadr poziomy: ${value.sidebar_x}%
            <input type="range" min="0" max="100" step="1" value=${value.sidebar_x} aria-label="Położenie tła menu" disabled=${!value.sidebar}
              onInput=${(e) => applyAppearance({ ...current, sidebar_x: Number(e.currentTarget.value) })}
              onChange=${(e) => commit({ sidebar_x: Number(e.currentTarget.value) })} />
          </label>
          <div class="reopen-position-labels"><span>Lewa strona zdjęcia</span><span>Prawa strona zdjęcia</span></div>
          <button type="button" class="btn small" disabled=${!value.sidebar} onClick=${() => commit({ sidebar_x: 50 })}>Wyśrodkuj kadr</button>
          <p class="small muted" style="margin-top:12px">Przesuwaj suwak — tło menu zmienia się na żywo. Podgląd zachowuje proporcje bocznego paska.</p>
        ` : html`<p class="small muted">Wypełnia cały ekran, zachowując proporcje zdjęcia. Nadmiar przy krawędziach jest przycinany.</p>`}
        <div class=${`reopen-preview ${slot === 'sidebar' ? 'reopen-preview-sidebar' : 'reopen-preview-loading'}`} style=${{
          backgroundImage: value[slot] && imageURL(slot) ? `linear-gradient(rgba(18,18,18,${value[`${slot}_dim`] / 100}),rgba(18,18,18,${value[`${slot}_dim`] / 100})),url("${imageURL(slot)}")` : 'none',
          backgroundPosition: slot === 'sidebar' ? `center, ${value.sidebar_x}% center` : 'center',
          aspectRatio: slot === 'sidebar' ? String(sidebarAspect) : '16 / 9',
          width: slot === 'sidebar' ? `${Math.min(130, 360 * sidebarAspect)}px` : '100%',
        }}>
          <b>${slot === 'loading' ? BRAND : 'Menu boczne'}</b><span>${slot === 'loading' ? `${DISPLAY_VERSION} · Ładowanie…` : 'Jazda · Zajezdnia · Ustawienia'}</span>
          ${slot === 'loading' && html`<div class="reopen-preview-bar"></div>`}
        </div>
        <button type="button" class="btn" disabled=${!value[slot]} onClick=${() => commit({ [slot]: false })}>Usuń tło</button>
      </section>`)}
      <section class="card card-body"><h2>Przywracanie</h2><p class="muted">Przywraca wygląd re-openOMSI. Nie zmienia map, pojazdów, sterowania ani grafiki gry.</p>
        <button type="button" class="btn" onClick=${() => commit(DEFAULTS)}>Przywróć domyślny wygląd</button>
      </section>
    </fieldset>
  </section>`;
}
