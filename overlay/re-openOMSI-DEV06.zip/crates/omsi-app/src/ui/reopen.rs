//! A bounded, optional loading image. One GPU texture, updated only at fade steps.
use super::*;

#[derive(Default)]
pub(super) struct LoadingAppearance {
    config: Option<omsi_platform::appearance::Appearance>,
    image: Option<omsi_texture::Image>,
    texture: Option<(TextureId, u8)>,
    tried_image: bool,
}
impl LoadingAppearance {
    fn config(&mut self) -> &omsi_platform::appearance::Appearance {
        self.config
            .get_or_insert_with(omsi_platform::appearance::load)
    }
    pub(super) fn accent(&mut self) -> [u8; 3] {
        let c = self.config().accent.as_bytes();
        let hex = |a: u8| (a as char).to_digit(16).unwrap_or(0) as u8;
        [
            hex(c[1]) * 16 + hex(c[2]),
            hex(c[3]) * 16 + hex(c[4]),
            hex(c[5]) * 16 + hex(c[6]),
        ]
    }
    pub(super) fn draw(
        &mut self,
        r: &Renderer,
        scene: &mut Scene,
        width: f32,
        height: f32,
        alpha: u8,
    ) {
        let config = self.config().clone();
        if !config.loading {
            return;
        }
        if !self.tried_image {
            self.tried_image = true;
            self.image = omsi_platform::appearance::image_path("loading").and_then(|p| {
                if std::fs::metadata(&p).ok()?.len()
                    > omsi_platform::appearance::MAX_PNG_BYTES as u64
                {
                    return None;
                }
                let bytes = std::fs::read(&p).ok()?;
                omsi_platform::appearance::validate_png(&bytes).ok()?;
                let mut image = omsi_texture::decode_file(&p).ok()?;
                // Bake dimming once. An invalid image simply keeps the original background.
                for pixel in image.rgba.chunks_exact_mut(4) {
                    for c in pixel.iter_mut().take(3) {
                        *c = (u32::from(*c) * u32::from(100 - config.loading_dim) / 100) as u8;
                    }
                }
                Some(image)
            });
        }
        let Some(image) = &self.image else { return };
        if self.texture.is_none_or(|(_, a)| a != alpha) {
            let mut faded = image.clone();
            for px in faded.rgba.chunks_exact_mut(4) {
                px[3] = (u32::from(px[3]) * u32::from(alpha) / 255) as u8;
            }
            if let Some((id, _)) = self.texture {
                r.update_texture(scene, id, &faded);
                self.texture = Some((id, alpha));
            } else {
                self.texture = Some((r.add_texture(scene, &faded, false), alpha));
            }
        }
        let factor = (width / image.width as f32).max(height / image.height as f32);
        let (w, h) = (image.width as f32 * factor, image.height as f32 * factor);
        let (x, y) = ((width - w) * 0.5, (height - h) * 0.5);
        if let Some((tex, _)) = self.texture {
            scene.overlays.push((tex, [x, y, x + w, y + h]));
        }
    }
    pub(super) fn release(&mut self, r: &Renderer, scene: &mut Scene) {
        if let Some((id, _)) = self.texture.take() {
            r.free_texture(scene, id);
        }
        self.image = None;
        self.tried_image = false;
        self.config = None;
    }
}
