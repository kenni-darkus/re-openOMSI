//! Optional presentation only. Separate from the simulator's settings and original content.
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

pub const NAME: &str = "re-openOMSI";
pub const DISPLAY_VERSION: &str = "0.3.41.1";
pub const UPSTREAM_VERSION: &str = "0.3.41";
pub const MAX_PNG_BYTES: usize = 6 * 1024 * 1024;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct Appearance {
    pub accent: String,
    pub amoled: bool,
    pub sidebar_dim: u8,
    pub sidebar_x: u8,
    pub loading_dim: u8,
    pub sidebar: bool,
    pub loading: bool,
}
impl Default for Appearance {
    fn default() -> Self {
        Self {
            accent: "#a78bfa".into(),
            amoled: false,
            sidebar_dim: 78,
            sidebar_x: 50,
            loading_dim: 65,
            sidebar: false,
            loading: false,
        }
    }
}
impl Appearance {
    pub fn checked(mut self) -> Self {
        if self.accent.len() != 7
            || !self.accent.starts_with('#')
            || !self.accent[1..].bytes().all(|x| x.is_ascii_hexdigit())
        {
            self.accent = Self::default().accent;
        }
        self.sidebar_dim = self.sidebar_dim.clamp(55, 95);
        self.sidebar_x = self.sidebar_x.min(100);
        self.loading_dim = self.loading_dim.clamp(40, 90);
        self
    }
}
pub fn directory() -> Option<PathBuf> {
    std::env::var_os("HOME")
        .or_else(|| std::env::var_os("USERPROFILE"))
        .map(|p| PathBuf::from(p).join(".openomsi").join("re-openomsi"))
}
pub fn load() -> Appearance {
    directory()
        .and_then(|p| std::fs::read(p.join("appearance.json")).ok())
        .and_then(|b| serde_json::from_slice::<Appearance>(&b).ok())
        .unwrap_or_default()
        .checked()
}
pub fn save(value: Appearance) -> Result<Appearance, String> {
    let value = value.checked();
    let dir = directory().ok_or("No user directory")?;
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let bytes = serde_json::to_vec_pretty(&value).map_err(|e| e.to_string())?;
    std::fs::write(dir.join("appearance.json.tmp"), bytes).map_err(|e| e.to_string())?;
    std::fs::rename(dir.join("appearance.json.tmp"), dir.join("appearance.json"))
        .map_err(|e| e.to_string())?;
    Ok(value)
}
pub fn image_path(slot: &str) -> Option<PathBuf> {
    matches!(slot, "sidebar" | "loading")
        .then(|| directory().map(|p| p.join(format!("{slot}.png"))))
        .flatten()
}
/// Images are rasterised by the browser first. Never accept paths or executable formats.
pub fn validate_png(bytes: &[u8]) -> Result<(), String> {
    if bytes.len() < 33
        || bytes.len() > MAX_PNG_BYTES
        || &bytes[..8] != b"\x89PNG\r\n\x1a\n"
        || &bytes[12..16] != b"IHDR"
    {
        return Err("Expected a PNG image, up to 6 MB".into());
    }
    let w = u32::from_be_bytes(bytes[16..20].try_into().unwrap());
    let h = u32::from_be_bytes(bytes[20..24].try_into().unwrap());
    if w == 0 || h == 0 || w > 1600 || h > 1600 || u64::from(w) * u64::from(h) > 1_440_000 {
        return Err("Image exceeds the 1600 px / 1.44 megapixel limit".into());
    }
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn invalid_colours_and_opacity_have_safe_defaults() {
        let a = Appearance {
            accent: "url(file:///x)".into(),
            sidebar_dim: 0,
            loading_dim: 255,
            ..Default::default()
        }
        .checked();
        assert_eq!(a.accent, "#a78bfa");
        assert_eq!(a.sidebar_dim, 55);
        assert_eq!(a.loading_dim, 90);
        assert_eq!(
            Appearance {
                accent: "#19aBC0".into(),
                ..Default::default()
            }
            .checked()
            .accent,
            "#19aBC0"
        );
    }
    #[test]
    fn old_appearance_files_keep_images_and_receive_a_centered_crop() {
        let old = r##"{"accent":"#60a5fa","sidebar_dim":82,"loading_dim":75,"sidebar":true,"loading":true}"##;
        let old: Appearance = serde_json::from_str(old).unwrap();
        assert_eq!(old.sidebar_x, 50);
        assert!(old.sidebar && old.loading);
        assert_eq!(old.sidebar_dim, 82);
        let moved = Appearance {
            sidebar_x: 255,
            ..old
        }
        .checked();
        assert_eq!(moved.sidebar_x, 100);
        let saved = serde_json::to_string(&moved).unwrap();
        assert_eq!(
            serde_json::from_str::<Appearance>(&saved)
                .unwrap()
                .sidebar_x,
            100
        );
    }
    #[test]
    fn reject_paths_bad_headers_and_oversized_images() {
        assert!(image_path("../settings").is_none());
        assert!(validate_png(b"<svg/>").is_err());
        let mut b = vec![0; 33];
        b[..8].copy_from_slice(b"\x89PNG\r\n\x1a\n");
        b[12..16].copy_from_slice(b"IHDR");
        b[16..20].copy_from_slice(&1600u32.to_be_bytes());
        b[20..24].copy_from_slice(&900u32.to_be_bytes());
        assert!(validate_png(&b).is_ok());
        b[20..24].copy_from_slice(&1600u32.to_be_bytes());
        assert!(validate_png(&b).is_err());
    }
}
